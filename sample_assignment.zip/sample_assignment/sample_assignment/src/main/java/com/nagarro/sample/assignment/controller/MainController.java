package com.nagarro.sample.assignment.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.sample.assignment.entity.AccountDetails;
import com.nagarro.sample.assignment.entity.AccountSearch;
import com.nagarro.sample.assignment.service.AccountImpl;

/**
 * @author Arunkumar Haridoss
 * 
 *         This controller is acting as a Main controller for all the services
 *         like Login,Logout , Masking the Account Number & Report generation
 *
 */
@Controller
public class MainController {

	@Autowired
	AccountImpl accountImpl;

	private static final Logger log = LoggerFactory.getLogger(MainController.class);

	@RequestMapping(value = { "/", "/login" }, method = RequestMethod.GET)
	public String welcomePage(Model model) {

		log.info("Login Page Loading");
		return "loginPage";
	}

	@RequestMapping(value = "/accountDetails", method = RequestMethod.GET)
	public String accountDetails(Model model) {

		log.info(" Login Success & Report Generation Page");
		return "AccountDetails";
	}

	@RequestMapping(value = "/statementPage", method = RequestMethod.GET)
	public String statementPage(Model model) {

		log.info(" Login Success & Report Generation Page");
		return "StatementPage";
	}

	/*
	 * @RequestMapping("/accountdetails") public ModelAndView adminDashboard() {
	 * return new ModelAndView("accountdetails"); }
	 */

	@RequestMapping(value = "/logoutSuccessful", method = RequestMethod.GET)
	public String logoutSuccessfulPage(Model model) {

		log.info("Logout Successful");

		model.addAttribute("title", "Logout");
		return "logoutSuccessfulPage";
	}

	@RequestMapping(value = "/getDetails", method = RequestMethod.POST)
	public String submitForm(@ModelAttribute("AccountSearch") AccountSearch accountSearch, BindingResult result, Model model) {
		
		
		
		String redirectPage="";
		
		// To get Logged in user Details
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		
				
		if(result.hasErrors())
	    {
			 accountSearch = new AccountSearch();
			 accountSearch.setAccountID(0);
	             
	    }
		

		log.info("Generating Report for given Data");

		List<AccountDetails> account = null;
		try {
			account = accountImpl.getAccountDetails(accountSearch);
			
			System.out.println("account ::::: " +account);
		} catch (Exception e) {
			// TODO Auto-generated catch block

			log.error(e.getMessage(), e);
		}

		List list = new ArrayList<>();

		AccountDetails accountList = null;
		String maskedValue = "";
		double round = 0.00;
		try {

			for (AccountDetails item : account) {

				accountList = new AccountDetails();

				round = Double.valueOf(item.getAmount());
				round = Math.round(round * 100) / 100;

				maskedValue = maskString(item.getAccountNumber().toString(), 0, 9, '*');

				// accountList.setAccountNumber("**********"+item.getAccountNumber().substring(8));  // This is also one of the way for masking
				accountList.setAccountNumber(maskedValue);
				accountList.setAccountType(item.getAccountType());
				accountList.setAmount(String.valueOf(round));
				accountList.setId(item.getId());
				accountList.setDate(item.getDate());

				list.add(accountList);
				
				

			}

		} catch (NullPointerException ex) {

			log.error(ex.getMessage(), ex);

		} catch (Exception e) {
			log.error(e.getMessage(), e);

		}
		
		if (list.size() >0)
			model.addAttribute("accountList", list);
		else
			
			model.addAttribute("error", "No data Available for the given criteria");
			
		
	if (auth.getName().equalsIgnoreCase("admin") && auth.getName().equals("admin"))
		
		redirectPage ="AccountDetails";
	else
		redirectPage ="StatementPage";
		
		
		return redirectPage;

	}

	private static String maskString(String strText, int start, int end, char maskChar) throws Exception {

		log.info("Masking the AccountNumber");

		if (strText == null || strText.equals(""))
			return "";

		if (start < 0)
			start = 0;

		if (end > strText.length())
			end = strText.length();

		if (start > end)
			throw new Exception("End index cannot be greater than start index");

		int maskLength = end - start;

		if (maskLength == 0)
			return strText;

		StringBuilder sbMaskString = new StringBuilder(maskLength);

		for (int i = 0; i < maskLength; i++) {
			sbMaskString.append(maskChar);
		}

		return strText.substring(0, start) + sbMaskString.toString() + strText.substring(start + maskLength);
	}

}
