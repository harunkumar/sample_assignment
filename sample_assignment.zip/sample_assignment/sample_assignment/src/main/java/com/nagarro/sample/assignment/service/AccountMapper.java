package com.nagarro.sample.assignment.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.nagarro.sample.assignment.entity.AccountDetails;


/**
 * @author Arunkumar Haridoss
 * 
 * This Mapper is using for assigning the resultset values.
 *
 */
public class AccountMapper implements RowMapper<AccountDetails> {

	@Override
	public AccountDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub

		int Id = rs.getInt("id");
		String accountType = rs.getString("account_type");
		String accountNumber = rs.getString("account_number");
		String date = rs.getString("datefield");
		String amount = rs.getString("amount");

		return new AccountDetails(Id, accountType, amount, date, accountNumber);
	}
}
